/*
 * Main_Code_Level_01_Hardware_Project 
 * Created: 17/12/2019 9:00:20 AM
 * Author : Pawara_Sachinthana
 *
 */ 

#define F_CPU 1000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include "i2c_lcd.h"



char str[4];

int piece =0;
int length=0;



static volatile int cnt_one;


 int main(void)
{
	
		lcd_init(LCD_BACKLIGHT_ON);		// Initialize I2C LCD.


/* ************************************************************* WELCOME DISPLAY **************************************************************************** */			
		lcd_clear();
		lcd_goto_xy(0,0);
		
		lcd_puts(" AUTOMATED ABRASIVE");
		lcd_puts("        SAW");
		
		_delay_ms(3000);
		lcd_clear();
/* ************************************************************* WELCOME DISPLAY **************************************************************************** */			
		
		


		DDRB = 0b00000000;	   // PIN DECLEARATION FOR PUSH BUTTONS
		PORTB =0b01111000;		// Set PINB3, PINB4, PINB5, PINB6 as in "NEXT" button, "UP" button, "BACK" button, "DOWN" button on control panel
		
		
		
		
/* ************************************************************* To feed the box bar manually ****************************************************** */
		lcd_clear();
		lcd_goto_xy(1,0);
		lcd_puts("Position box bar");
		lcd_goto_xy(0,1);
		lcd_puts(" under feeder roller");
		_delay_ms(1000);
		lcd_goto_xy(0,2);
		lcd_puts("UP arrow to feed");
		lcd_goto_xy(0,3);
		lcd_puts("Press -> to continue ");
		_delay_ms(500);
		
		while(!bit_is_clear(PINB,3))		//To feed the box bar manually
		{
			DDRA = 0b01110000;
			
			if(bit_is_clear(PINB,4))
			{ 
				PORTA = 0b00100000;			// PA4--> EN, PA5--> INT1-->1, PA6-->INT2-->0, OUTPUT1 & OUTPUT 2 }--> Feeder motor forward rotating
			}
			
			if((!bit_is_clear(PINB,4)) && (!bit_is_clear(PINB,6)))
			{
				PORTA = 0b00000000;			// PA4--> EN, PA5--> INT1, PA6-->INT2, OUTPUT1 & OUTPUT 2 }--> Feeder motor stop rotating
			} 
			
			if(bit_is_clear(PINB,6))
			{
				PORTA = 0b01000000;			// PA4--> EN, PA5--> INT1-->0, PA6-->INT2-->1, OUTPUT1 & OUTPUT 2 }--> Feeder motor backward rotating
			}
			
			
		}
/* ************************************************************* To feed the box bar manually ****************************************************** */		
	
		
		
		
/* ************************************************************* INPUT LENGTH **************************************************************************** */	
		lcd_clear();
		lcd_goto_xy(0,0);
		lcd_puts("Enter length & NO."); 
		lcd_goto_xy(0,1);
		lcd_puts("of pieces"); 
		_delay_ms(2000);
		lcd_clear();
		
		lcd_goto_xy(0,0);
		lcd_puts("Enter length (cm):-");
		
		while (!bit_is_clear(PINB,3))
		{
			
			
			if(bit_is_clear(PINB,4) && length<50)
			{
				length = length+1;
				_delay_ms(200);
			}
			if(bit_is_clear(PINB,6) && length>0)
			{
				length = length-1;
				_delay_ms(200);
			}
			
			
			itoa(length,str,10);
			lcd_goto_xy(2,1);
			lcd_puts(str);
			
			continue;
		}
/* ************************************************************* INPUT LENGTH **************************************************************************** */		
		
		
		
		
/* ************************************************************* INPUT NO. OF PIECES ********************************************************************* */	
		
		_delay_ms(1000);
		lcd_goto_xy(0,2);
		lcd_puts("Number of pieces:- ");
		
		while (!bit_is_clear(PINB,3))
		{
			

			if(bit_is_clear(PINB,4))
			{
				piece = piece+1;
				_delay_ms(200);
			}
			if(bit_is_clear(PINB,6) && piece>0)
			{
				piece = piece-1;
				_delay_ms(200);
			}
			
			
			itoa(piece,str,10);
			lcd_goto_xy(2,3);
			lcd_puts(str);
			
			continue;
		}
/* ************************************************************* INPUT NO. OF PIECES ********************************************************************* */




/* ************************************************************* VERIFY INPUTS ********************************************************************* */
		_delay_ms(1000);
		lcd_clear();
		lcd_goto_xy(0,0);
		lcd_puts("Unit Length =");
		_delay_ms(500);
		itoa(length,str,10);
		lcd_goto_xy(15,0);
		lcd_puts(str);
		lcd_goto_xy(18,0);
		lcd_puts("cm");
		
		_delay_ms(1000);
		lcd_goto_xy(0,1);
		lcd_puts("No. of Pieces =");
		_delay_ms(500);
		itoa(piece,str,10);
		lcd_goto_xy(17,1);
		lcd_puts(str);
		
		_delay_ms(1000);
		lcd_goto_xy(0,2);
		lcd_puts("Press '-->' to Start");
		_delay_ms(500);
		lcd_goto_xy(0,3);
		lcd_puts("Press '<--' to Stop");
		_delay_ms(500);
	
		
		while(!bit_is_clear(PINB,3))	//To Proceed forward
		{
			
		}
/* ************************************************************* VERIFY INPUTS ********************************************************************* */		
		
		


		for(int i=0;i<4;i++)
		{
			lcd_clear();
			_delay_ms(200);
			lcd_goto_xy(0,1);
			lcd_puts("Initiating......");
			_delay_ms(200);
			
		}
		 
		
		
	DDRD = 0b11110011;				//To set PIND2(Photoelectric encoder) and PIND3(Limit Switch) as input pins		
	
	if(bit_is_clear(PIND,3))		//To check whether the box bar is in the range
		{
			int num_turn = 0;
		
			while(num_turn<piece)
			{
		
/* ************************************************************* ENABLE INTERRUPTS **************************************************************************** */		
				GICR |=(1<<INT0);   //only Enable External Interrupts INT0
				MCUCR|=(1<<ISC00)|(1<<ISC01); //Configure INT0 active raising edge triggered
			
				sei();     // Enable global interrupts by setting global interrupt enable bit in SREG
/* ************************************************************* ENABLE INTERRUPTS **************************************************************************** */				
			
			
			
			
				lcd_clear();
				lcd_goto_xy(2,0);
				lcd_puts("Rem. No. Pieces:");
				itoa((piece-num_turn),str,10);
				lcd_goto_xy(2,1);
				lcd_puts(str);
			
				lcd_goto_xy(2,2);
				lcd_puts("Length in cm:");
			
			
			
		
/* ************************************************************* FEEDER CONTROL **************************************************************************** */			
				while(cnt_one<=((length*10)/3))
				{
				
					DDRA = 0b01110000;
					PORTA = 0b00100000;			// PA4--> EN, PA5--> INT1, PA6-->INT2, OUTPUT1 & OUTPUT 2 }--> Feeder motor start rotating
				
				
					itoa(((cnt_one/10)*3),str,10);	
					lcd_goto_xy(2,3);	
					lcd_puts(str);

				}

			
				PORTA = 0b00000000;				// PA4--> EN, PA5--> INT1, PA6-->INT2, OUTPUT1 & OUTPUT 2 }--> Feeder motor stop rotating
				_delay_ms(1000);
/* ************************************************************* FEEDER CONTROL **************************************************************************** */				




/* ************************************************************* FASTENER MOVE FORWARD **************************************************************************** */		
				DDRA = 0b00001110;					// PA1--> EN, PA2--> INT1, PA3-->INT2, OUTPUT3 & OUTPUT4 }--> Fastener motor move forward
				PORTA = 0b00000100;
				_delay_ms(2000);
				PORTA = 0b00000000;					// PA1--> EN, PA2--> INT1, PA3-->INT2, OUTPUT3 & OUTPUT4 }--> Fastener motor stop
				_delay_ms(1000);
/* ************************************************************* fASTENER MOVE FORWARD **************************************************************************** */				
			
			
			
			
/* ************************************************************* HIGH RPM MOTOR START **************************************************************************** */	
				DDRA  = 0b00000001;
				PORTA = 0b00000001;
				_delay_ms(2000);
/* ************************************************************* HIGH RPM MOTOR START **************************************************************************** */		
			



/* ************************************************************* STEPPER MOTOR START **************************************************************************** */		
				DDRD = 0b11110000;															// Set PORTD as output pins
			
				DDRB = 0b11111100;															// Set PB0 and PB1 as input pins
			
																					// Stepper move forward
				while (((PINB & 0b00000001) !=1) || ((PINB & 0b00000010) !=0))		// PB0--> IR1	PB1--> IR2
				{
					PORTD = 0b01100000;												// PD7--> EN		PD6--> DIR    PD5-->PUL
					_delay_ms(60);
					PORTD = 0b01000000;
					_delay_ms(60);	
				}
				
				
				
				/* ************************************************************* HIGH RPM MOTOR STOP **************************************************************************** */
				PORTA = 0b00000000;
				_delay_ms(500);
				/* ************************************************************* HIGH RPM MOTOR STOP **************************************************************************** */
				
				
				
				
				while(((PINB & 0b00000001) !=0) && ((PINB & 0b00000010) !=1))		// Stepper move reverse
				{
					PORTD = 0b00100000;
					_delay_ms(4);
					PORTD = 0b00000000;
					_delay_ms(4);	
				}
/* ************************************************************* STEPPER MOTOR STOP **************************************************************************** */			
		



/* **************************************************************** SERVO MOTOR ********************************************************************************** */
				DDRD = 0b00010000;				 
				PORTD = 0b00010000;

				int i;
					_delay_ms(1000);
					
					for(i=0;i<50;i++)			 /*to rotate ejector about 180 to eject the separated box bar piece */
					{
						PORTD = 0x10;
						_delay_us(1750);
						PORTD = 0x00;
						_delay_us(18250);
					}
					
					
					
					for(i=0;i<50;i++)			 /*to rotate ejector to the previous position */
					{
						PORTD = 0x10;
						_delay_us(500);
						PORTD = 0x00;
						_delay_us(19500);
					} 


					_delay_us(2000);
/* **************************************************************** SERVO MOTOR ********************************************************************************** */




		
/* ************************************************************* fASTENER MOVE REVERSE **************************************************************************** */
				DDRA = 0b00001110;					// PA1--> EN, PA2--> INT1, PA3-->INT2, OUTPUT3 & OUTPUT4 }--> Fastener motor move Backward
				PORTA = 0b00001000;
				_delay_ms(2000);
				PORTA = 0b00000000;					// PA1--> EN, PA2--> INT1, PA3-->INT2, OUTPUT3 & OUTPUT4 }--> Fastener motor stop
/* ************************************************************* fASTENER MOVE REVERSE **************************************************************************** */
	
	
				
				cnt_one = 0;
				lcd_clear();
				num_turn +=1;
	
			}
	
	
			lcd_clear();
			lcd_goto_xy(1,1);
			lcd_puts("Task Completed...!");
	
		}
	
	
	
	else
	{
		lcd_clear();
		lcd_goto_xy(1,1);
		lcd_puts("Insert new box bar");
	}
	
	
	 
}




ISR (INT0_vect)        //External interrupt_one ISR
{
	cnt_one++;
}





